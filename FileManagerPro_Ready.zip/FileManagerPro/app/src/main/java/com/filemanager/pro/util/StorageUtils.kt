package com.filemanager.pro.util

import android.os.Environment
import android.os.StatFs
import java.text.DecimalFormat
import java.util.Locale

/**
 * Reads REAL storage statistics from the device's file system.
 * No fake or hardcoded numbers — this reflects the actual internal storage.
 */
object StorageUtils {

    data class StorageStats(
        val totalBytes: Long,
        val usedBytes: Long,
        val freeBytes: Long,
        val usedPercent: Int
    )

    fun getInternalStorageStats(): StorageStats {
        val path = Environment.getDataDirectory()
        val stat = StatFs(path.path)
        val blockSize = stat.blockSizeLong
        val totalBlocks = stat.blockCountLong
        val availableBlocks = stat.availableBlocksLong

        val totalBytes = totalBlocks * blockSize
        val freeBytes = availableBlocks * blockSize
        val usedBytes = totalBytes - freeBytes
        val usedPercent = if (totalBytes > 0) ((usedBytes * 100) / totalBytes).toInt() else 0

        return StorageStats(totalBytes, usedBytes, freeBytes, usedPercent)
    }

    fun formatBytes(bytes: Long): String {
        if (bytes <= 0) return "0 B"
        val units = arrayOf("B", "KB", "MB", "GB", "TB")
        var value = bytes.toDouble()
        var unitIndex = 0
        while (value >= 1024 && unitIndex < units.size - 1) {
            value /= 1024
            unitIndex++
        }
        val df = DecimalFormat("#.#")
        return "${df.format(value)} ${units[unitIndex]}"
    }

    fun formatBytesGb(bytes: Long): String {
        val gb = bytes / (1024.0 * 1024.0 * 1024.0)
        return String.format(Locale.US, "%.1f GB", gb)
    }
}

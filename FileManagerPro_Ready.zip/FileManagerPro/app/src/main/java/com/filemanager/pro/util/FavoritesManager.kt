package com.filemanager.pro.util

import android.content.Context

/**
 * Persists the set of file paths the user has starred as favorites,
 * in real SharedPreferences — survives app restarts.
 */
object FavoritesManager {
    private const val PREFS = "fmp_favorites_prefs"
    private const val KEY_PATHS = "favorite_paths"

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun isFavorite(context: Context, path: String): Boolean =
        prefs(context).getStringSet(KEY_PATHS, emptySet())?.contains(path) == true

    fun toggle(context: Context, path: String): Boolean {
        val current = prefs(context).getStringSet(KEY_PATHS, emptySet())?.toMutableSet() ?: mutableSetOf()
        val nowFavorite = if (current.contains(path)) {
            current.remove(path); false
        } else {
            current.add(path); true
        }
        prefs(context).edit().putStringSet(KEY_PATHS, current).apply()
        return nowFavorite
    }

    fun getAll(context: Context): List<String> =
        prefs(context).getStringSet(KEY_PATHS, emptySet())?.toList() ?: emptyList()

    fun remove(context: Context, path: String) {
        val current = prefs(context).getStringSet(KEY_PATHS, emptySet())?.toMutableSet() ?: mutableSetOf()
        current.remove(path)
        prefs(context).edit().putStringSet(KEY_PATHS, current).apply()
    }
}

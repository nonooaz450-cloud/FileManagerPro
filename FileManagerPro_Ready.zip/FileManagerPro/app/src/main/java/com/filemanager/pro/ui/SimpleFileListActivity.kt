package com.filemanager.pro.ui

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.filemanager.pro.R
import com.filemanager.pro.adapter.FileAdapter
import com.filemanager.pro.model.FileItem
import com.filemanager.pro.util.FavoritesManager
import com.filemanager.pro.util.FileUtils
import java.io.File
import kotlin.concurrent.thread

/**
 * One reusable, real results screen for Favorites, Large Files, Duplicates
 * and Search — each mode loads real data via FileUtils / FavoritesManager,
 * nothing mocked.
 */
class SimpleFileListActivity : AppCompatActivity() {

    private lateinit var adapter: FileAdapter
    private lateinit var mode: String
    private var query: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_simple_file_list)

        mode = intent.getStringExtra(EXTRA_MODE) ?: MODE_FAVORITES
        query = intent.getStringExtra(EXTRA_QUERY) ?: ""

        findViewById<View>(R.id.btnBack).setOnClickListener { finish() }
        findViewById<TextView>(R.id.tvTitle).text = titleFor(mode)

        val rv = findViewById<RecyclerView>(R.id.rvResults)
        rv.layoutManager = LinearLayoutManager(this)
        adapter = FileAdapter(emptyList(), onClick = { openFile(it) }, onMoreClick = { showOptions(it) })
        rv.adapter = adapter

        load()
    }

    private fun titleFor(mode: String) = when (mode) {
        MODE_FAVORITES -> "FAVORITES"
        MODE_LARGE -> "LARGE FILES"
        MODE_DUPLICATES -> "DUPLICATE FILES"
        MODE_SEARCH -> "SEARCH: \"$query\""
        else -> "FILES"
    }

    private fun load() {
        thread {
            val list: List<FileItem> = when (mode) {
                MODE_FAVORITES -> FavoritesManager.getAll(this)
                    .map { File(it) }.filter { it.exists() }.map { FileItem.fromFile(it) }
                MODE_LARGE -> FileUtils.findLargestFiles()
                MODE_DUPLICATES -> FileUtils.findDuplicateFiles()
                MODE_SEARCH -> FileUtils.searchFiles(query)
                else -> emptyList()
            }
            runOnUiThread {
                adapter.updateData(list)
                findViewById<TextView>(R.id.tvEmpty).apply {
                    visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
                    text = if (mode == MODE_SEARCH) "No files match \"$query\"" else "Nothing to show here"
                }
            }
        }
    }

    private fun openFile(item: FileItem) {
        if (item.isDirectory) {
            Toast.makeText(this, item.path, Toast.LENGTH_SHORT).show()
            return
        }
        try {
            val file = File(item.path)
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
            val mimeType = contentResolver.getType(uri) ?: "*/*"
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, mimeType)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(this, "No app found to open this file", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showOptions(item: FileItem) {
        val isFav = FavoritesManager.isFavorite(this, item.path)
        val favLabel = if (isFav) "Remove from favorites" else "Add to favorites"
        val options = arrayOf("Open", favLabel, "Share", "Delete")
        android.app.AlertDialog.Builder(this)
            .setTitle(item.name)
            .setItems(options) { _, which ->
                when (which) {
                    0 -> openFile(item)
                    1 -> {
                        FavoritesManager.toggle(this, item.path)
                        if (mode == MODE_FAVORITES) load()
                    }
                    2 -> shareFile(item)
                    3 -> deleteFile(item)
                }
            }.show()
    }

    private fun shareFile(item: FileItem) {
        try {
            val file = File(item.path)
            val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "*/*"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(intent, "Share ${item.name}"))
        } catch (e: Exception) {
            Toast.makeText(this, "Unable to share file", Toast.LENGTH_SHORT).show()
        }
    }

    private fun deleteFile(item: FileItem) {
        android.app.AlertDialog.Builder(this)
            .setTitle("Delete ${item.name}?")
            .setMessage("This will permanently delete the file from your device.")
            .setPositiveButton("Delete") { _, _ ->
                val ok = File(item.path).deleteRecursively()
                if (ok) FavoritesManager.remove(this, item.path)
                Toast.makeText(this, if (ok) "Deleted" else "Could not delete file", Toast.LENGTH_SHORT).show()
                load()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    companion object {
        const val EXTRA_MODE = "extra_mode"
        const val EXTRA_QUERY = "extra_query"
        const val MODE_FAVORITES = "favorites"
        const val MODE_LARGE = "large"
        const val MODE_DUPLICATES = "duplicates"
        const val MODE_SEARCH = "search"
    }
}

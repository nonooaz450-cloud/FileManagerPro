package com.filemanager.pro.adapter

import android.graphics.Color
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.filemanager.pro.R
import com.filemanager.pro.model.CategoryItem

class CategoryAdapter(
    private val items: List<CategoryItem>,
    private val onClick: (CategoryItem) -> Unit
) : RecyclerView.Adapter<CategoryAdapter.VH>() {

    class VH(view: android.view.View) : RecyclerView.ViewHolder(view) {
        val root: android.view.View = view.findViewById(R.id.root)
        val iconBg: android.view.View = view.findViewById(R.id.iconBg)
        val name: android.widget.TextView = view.findViewById(R.id.tvName)
        val count: android.widget.TextView = view.findViewById(R.id.tvCount)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_category, parent, false)
        return VH(v)
    }

    override fun getItemCount() = items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = items[position]
        holder.name.text = item.label
        holder.count.text = item.count.toString()
        holder.iconBg.background?.mutate()
        holder.iconBg.backgroundTintList = android.content.res.ColorStateList.valueOf(Color.parseColor(item.colorHex))
        holder.iconBg.setBackgroundResource(R.drawable.shape_icon_rounded)
        holder.iconBg.backgroundTintList = android.content.res.ColorStateList.valueOf(Color.parseColor(item.bgHex))
        holder.root.setOnClickListener { onClick(item) }
    }
}

package com.filemanager.pro.ui

import android.os.Bundle
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.filemanager.pro.R
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.floatingactionbutton.FloatingActionButton

class MainActivity : AppCompatActivity() {

    private val homeFragment = HomeFragment()
    private val filesFragment = FilesFragment()
    private val recentFragment = RecentFragment()
    private val settingsFragment = SettingsFragment()
    private var activeTabId = R.id.nav_home

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        showFragment(homeFragment)

        val bottomNav = findViewById<BottomNavigationView>(R.id.bottomNav)
        bottomNav.setOnItemSelectedListener { item ->
            activeTabId = item.itemId
            when (item.itemId) {
                R.id.nav_home -> { showFragment(homeFragment); true }
                R.id.nav_files -> { showFragment(filesFragment); true }
                R.id.nav_recent -> { showFragment(recentFragment); true }
                R.id.nav_settings -> { showFragment(settingsFragment); true }
                else -> false
            }
        }

        findViewById<FloatingActionButton>(R.id.fab).setOnClickListener {
            showFragment(filesFragment)
            bottomNav.selectedItemId = R.id.nav_files
            filesFragment.promptNewFolder()
        }

        // Real back-button handling: inside Files, back first exits selection mode,
        // then steps up a folder at a time; only once at the top does it fall through
        // to the default behavior (go Home, then exit on a second press).
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (activeTabId == R.id.nav_files && filesFragment.onBackPressedInTab()) return
                if (activeTabId != R.id.nav_home) {
                    activeTabId = R.id.nav_home
                    bottomNav.selectedItemId = R.id.nav_home
                    return
                }
                isEnabled = false
                onBackPressedDispatcher.onBackPressed()
            }
        })
    }

    private fun showFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragmentContainer, fragment)
            .commit()
    }

    /** Called by fragments (e.g. Files) to switch tabs programmatically. */
    fun switchToFilesTab() {
        activeTabId = R.id.nav_files
        findViewById<BottomNavigationView>(R.id.bottomNav).selectedItemId = R.id.nav_files
    }
}

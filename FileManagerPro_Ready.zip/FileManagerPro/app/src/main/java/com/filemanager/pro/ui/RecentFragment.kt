package com.filemanager.pro.ui

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.filemanager.pro.R
import com.filemanager.pro.adapter.FileAdapter
import com.filemanager.pro.model.FileItem
import com.filemanager.pro.util.FileUtils
import java.io.File
import kotlin.concurrent.thread

class RecentFragment : Fragment(R.layout.fragment_recent) {

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val rv = view.findViewById<RecyclerView>(R.id.rvRecent)
        rv.layoutManager = LinearLayoutManager(requireContext())
        val adapter = FileAdapter(emptyList(), onClick = { open(it) }, onMoreClick = { open(it) })
        rv.adapter = adapter

        thread {
            val files = FileUtils.getRecentFiles(requireContext(), limit = 50)
            activity?.runOnUiThread { adapter.updateData(files) }
        }
    }

    private fun open(item: FileItem) {
        try {
            val file = File(item.path)
            val uri = FileProvider.getUriForFile(
                requireContext(), "${requireContext().packageName}.fileprovider", file
            )
            val mime = requireContext().contentResolver.getType(uri) ?: "*/*"
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, mime)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(requireContext(), "No app found to open this file", Toast.LENGTH_SHORT).show()
        }
    }
}

package com.filemanager.pro.util

import android.content.Context
import java.security.MessageDigest

/**
 * Stores the user's app-lock PIN as a salted SHA-256 hash in SharedPreferences.
 * The raw PIN is never stored on disk.
 */
object PinManager {
    private const val PREFS = "fmp_secure_prefs"
    private const val KEY_HASH = "pin_hash"
    private const val SALT = "FMP_v1_salt_9F2A"

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun hasPin(context: Context): Boolean =
        prefs(context).contains(KEY_HASH)

    fun setPin(context: Context, pin: String) {
        prefs(context).edit().putString(KEY_HASH, hash(pin)).apply()
    }

    fun verifyPin(context: Context, pin: String): Boolean {
        val stored = prefs(context).getString(KEY_HASH, null) ?: return false
        return stored == hash(pin)
    }

    /** Real reset: erases the stored PIN hash so the next launch goes through "create PIN" again. */
    fun clearPin(context: Context) {
        prefs(context).edit().remove(KEY_HASH).apply()
    }

    private fun hash(pin: String): String {
        val digest = MessageDigest.getInstance("SHA-256")
        val bytes = digest.digest((SALT + pin).toByteArray(Charsets.UTF_8))
        return bytes.joinToString("") { "%02x".format(it) }
    }
}

package com.filemanager.pro.adapter

import android.graphics.Color
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.filemanager.pro.R
import com.filemanager.pro.model.FileItem
import com.filemanager.pro.util.FileUtils
import com.filemanager.pro.util.StorageUtils
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class FileAdapter(
    private var items: List<FileItem>,
    private val onClick: (FileItem) -> Unit,
    private val onMoreClick: (FileItem) -> Unit,
    private val onLongClick: (FileItem) -> Unit = {}
) : RecyclerView.Adapter<FileAdapter.VH>() {

    private val dateFmt = SimpleDateFormat("MMM d, h:mm a", Locale.getDefault())

    /** Real multi-select support: which paths are checked, and whether we're in selection mode. */
    var selectionMode: Boolean = false
        private set
    private val selectedPaths = mutableSetOf<String>()

    class VH(view: android.view.View) : RecyclerView.ViewHolder(view) {
        val checkBox: CheckBox = view.findViewById(R.id.cbSelect)
        val iconBg: android.view.View = view.findViewById(R.id.fileIconBg)
        val icon: ImageView = view.findViewById(R.id.ivFileIcon)
        val name: TextView = view.findViewById(R.id.tvFileName)
        val meta: TextView = view.findViewById(R.id.tvFileMeta)
        val size: TextView = view.findViewById(R.id.tvFileSize)
        val more: ImageView = view.findViewById(R.id.ivMore)
    }

    fun updateData(newItems: List<FileItem>) {
        items = newItems
        // Drop selections that no longer exist in the current listing (e.g. after navigating).
        selectedPaths.retainAll(newItems.map { it.path }.toSet())
        notifyDataSetChanged()
    }

    fun setSelectionMode(enabled: Boolean) {
        selectionMode = enabled
        if (!enabled) selectedPaths.clear()
        notifyDataSetChanged()
    }

    fun toggleSelection(item: FileItem) {
        if (selectedPaths.contains(item.path)) selectedPaths.remove(item.path) else selectedPaths.add(item.path)
        notifyDataSetChanged()
    }

    fun getSelectedItems(): List<FileItem> = items.filter { selectedPaths.contains(it.path) }
    fun selectedCount(): Int = selectedPaths.size

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context).inflate(R.layout.item_file, parent, false)
        return VH(v)
    }

    override fun getItemCount() = items.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = items[position]
        holder.name.text = item.name
        val label = FileUtils.getFileTypeLabel(item)
        holder.meta.text = "$label • ${dateFmt.format(Date(item.lastModified))}"
        holder.size.text = if (item.isDirectory) "" else StorageUtils.formatBytes(item.sizeBytes)

        val (bg, iconRes) = iconFor(item)
        holder.iconBg.backgroundTintList = android.content.res.ColorStateList.valueOf(Color.parseColor(bg))
        holder.icon.setImageResource(iconRes)

        holder.checkBox.visibility = if (selectionMode) android.view.View.VISIBLE else android.view.View.GONE
        holder.checkBox.isChecked = selectedPaths.contains(item.path)
        holder.more.visibility = if (selectionMode) android.view.View.GONE else android.view.View.VISIBLE
        holder.itemView.setBackgroundColor(
            if (selectedPaths.contains(item.path)) Color.parseColor("#1A2F8FFF") else Color.TRANSPARENT
        )

        holder.itemView.setOnClickListener {
            if (selectionMode) toggleSelection(item) else onClick(item)
        }
        holder.itemView.setOnLongClickListener {
            onLongClick(item)
            true
        }
        holder.more.setOnClickListener { onMoreClick(item) }
    }

    private fun iconFor(item: FileItem): Pair<String, Int> {
        if (item.isDirectory) return "#332F8FFF" to android.R.drawable.ic_menu_agenda
        return when (item.extension) {
            "apk" -> "#3320C96B" to android.R.drawable.sym_def_app_icon
            "pdf" -> "#33EF4444" to android.R.drawable.ic_menu_agenda
            "jpg", "jpeg", "png", "webp", "gif" -> "#33C026D3" to android.R.drawable.ic_menu_gallery
            "mp4", "mkv", "mov", "avi" -> "#332F8FFF" to android.R.drawable.ic_media_play
            "mp3", "wav", "m4a", "flac" -> "#3320C96B" to android.R.drawable.ic_lock_silent_mode_off
            "zip", "rar", "7z" -> "#338B4DFF" to android.R.drawable.ic_menu_save
            else -> "#33F5A524" to android.R.drawable.ic_menu_agenda
        }
    }
}

package com.filemanager.pro.ui

import android.app.AlertDialog
import android.content.Context
import android.view.Gravity
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import com.filemanager.pro.util.FileUtils
import java.io.File

/**
 * A small real folder browser used to pick a destination for Copy / Move.
 * Shows only real directories on the device and lets the user drill down
 * or pick the folder currently open.
 */
class FolderPickerDialog(
    private val context: Context,
    startDir: File,
    private val onPicked: (File) -> Unit
) {
    private var currentDir: File = startDir
    private lateinit var dialog: AlertDialog
    private lateinit var listView: ListView
    private lateinit var pathLabel: TextView
    private lateinit var adapter: ArrayAdapter<String>
    private var subDirs: List<File> = emptyList()

    fun show() {
        val container = LinearLayout(context).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 24, 32, 8)
        }

        pathLabel = TextView(context).apply {
            textSize = 12f
            setPadding(0, 0, 0, 16)
        }
        container.addView(pathLabel)

        listView = ListView(context)
        adapter = ArrayAdapter(context, android.R.layout.simple_list_item_1, mutableListOf())
        listView.adapter = adapter
        listView.setOnItemClickListener { _, _, position, _ ->
            currentDir = subDirs[position]
            refresh()
        }
        container.addView(
            listView,
            LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 700)
        )

        val buttonRow = LinearLayout(context).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.END
            setPadding(0, 16, 0, 0)
        }
        val upBtn = Button(context).apply {
            text = "⬆ Up"
            setOnClickListener {
                currentDir.parentFile?.let { parent ->
                    if (parent.canRead()) { currentDir = parent; refresh() }
                }
            }
        }
        buttonRow.addView(upBtn)
        container.addView(buttonRow)

        dialog = AlertDialog.Builder(context)
            .setTitle("Choose destination")
            .setView(container)
            .setPositiveButton("Select this folder") { _, _ -> onPicked(currentDir) }
            .setNegativeButton("Cancel", null)
            .create()

        refresh()
        dialog.show()
    }

    private fun refresh() {
        pathLabel.text = currentDir.absolutePath
        subDirs = FileUtils.listDirectory(currentDir).filter { it.isDirectory }.map { File(it.path) }
        adapter.clear()
        adapter.addAll(subDirs.map { "📁  ${it.name}" })
        adapter.notifyDataSetChanged()
    }
}

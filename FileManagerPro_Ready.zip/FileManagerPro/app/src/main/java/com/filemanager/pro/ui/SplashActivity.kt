package com.filemanager.pro.ui

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AppCompatActivity
import com.filemanager.pro.util.PinManager

class SplashActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Handler(Looper.getMainLooper()).postDelayed({
            val next = Intent(this, LoginActivity::class.java)
            startActivity(next)
            finish()
        }, 600)
    }
}

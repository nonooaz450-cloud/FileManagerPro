package com.filemanager.pro.ui

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.filemanager.pro.R
import com.filemanager.pro.adapter.FileAdapter
import com.filemanager.pro.model.FileItem
import com.filemanager.pro.util.FavoritesManager
import com.filemanager.pro.util.FileUtils
import java.io.File
import kotlin.concurrent.thread

class FilesFragment : Fragment(R.layout.fragment_files) {

    private var currentDir: File = FileUtils.rootDirectory()
    private lateinit var rv: RecyclerView
    private lateinit var tvPath: TextView
    private lateinit var adapter: FileAdapter
    private lateinit var selectionBar: View
    private lateinit var tvSelectionCount: TextView

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        rv = view.findViewById(R.id.rvFiles)
        tvPath = view.findViewById(R.id.tvCurrentPath)
        selectionBar = view.findViewById(R.id.selectionBar)
        tvSelectionCount = view.findViewById(R.id.tvSelectionCount)
        rv.layoutManager = LinearLayoutManager(requireContext())

        adapter = FileAdapter(
            emptyList(),
            onClick = { item -> onItemClick(item) },
            onMoreClick = { item -> showOptions(item) },
            onLongClick = { item -> enterSelectionMode(item) }
        )
        rv.adapter = adapter

        view.findViewById<View>(R.id.btnNewFolder).setOnClickListener { showCreateFolderDialog() }
        wireSelectionBar(view)

        loadCurrentDir()
    }

    private fun wireSelectionBar(view: View) {
        view.findViewById<View>(R.id.btnSelCancel).setOnClickListener { exitSelectionMode() }
        view.findViewById<View>(R.id.btnSelDelete).setOnClickListener { bulkDelete() }
        view.findViewById<View>(R.id.btnSelCopy).setOnClickListener { bulkCopyOrMove(move = false) }
        view.findViewById<View>(R.id.btnSelMove).setOnClickListener { bulkCopyOrMove(move = true) }
        view.findViewById<View>(R.id.btnSelZip).setOnClickListener { bulkZip() }
    }

    private fun enterSelectionMode(item: FileItem) {
        adapter.setSelectionMode(true)
        adapter.toggleSelection(item)
        selectionBar.visibility = View.VISIBLE
        updateSelectionCount()
    }

    private fun exitSelectionMode() {
        adapter.setSelectionMode(false)
        selectionBar.visibility = View.GONE
    }

    private fun updateSelectionCount() {
        tvSelectionCount.text = "${adapter.selectedCount()} selected"
    }

    private fun onItemClick(item: FileItem) {
        if (adapter.selectionMode) {
            adapter.toggleSelection(item)
            updateSelectionCount()
            return
        }
        if (item.isDirectory) {
            currentDir = File(item.path)
            loadCurrentDir()
        } else {
            openFile(item)
        }
    }

    private fun loadCurrentDir() {
        tvPath.text = currentDir.absolutePath
        thread {
            val list = FileUtils.listDirectory(currentDir)
            activity?.runOnUiThread { adapter.updateData(list) }
        }
    }

    /** Real back-navigation: exit selection mode first, then pop to parent folder. */
    fun onBackPressedInTab(): Boolean {
        if (adapter.selectionMode) {
            exitSelectionMode()
            return true
        }
        val parent = currentDir.parentFile
        return if (parent != null && currentDir != FileUtils.rootDirectory()) {
            currentDir = parent
            loadCurrentDir()
            true
        } else false
    }

    private fun openFile(item: FileItem) {
        try {
            val file = File(item.path)
            val uri = FileProvider.getUriForFile(
                requireContext(), "${requireContext().packageName}.fileprovider", file
            )
            val mime = requireContext().contentResolver.getType(uri) ?: "*/*"
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, mime)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(requireContext(), "No app found to open this file", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showOptions(item: FileItem) {
        val isFav = FavoritesManager.isFavorite(requireContext(), item.path)
        val favLabel = if (isFav) "Remove from favorites" else "Add to favorites"
        val options = mutableListOf("Open", "Select", "Rename", "Copy to…", "Move to…", favLabel)
        if (item.extension == "zip") options.add("Extract here")
        if (!item.isDirectory) options.add("Compress to .zip")
        options.add("Share")
        options.add("Delete")

        android.app.AlertDialog.Builder(requireContext())
            .setTitle(item.name)
            .setItems(options.toTypedArray()) { _, which ->
                when (options[which]) {
                    "Open" -> onItemClick(item)
                    "Select" -> enterSelectionMode(item)
                    "Rename" -> showRenameDialog(item)
                    "Copy to…" -> showDestinationPicker(item, move = false)
                    "Move to…" -> showDestinationPicker(item, move = true)
                    favLabel -> {
                        FavoritesManager.toggle(requireContext(), item.path)
                        val msg = if (isFav) "Removed from favorites" else "Added to favorites"
                        Toast.makeText(requireContext(), msg, Toast.LENGTH_SHORT).show()
                    }
                    "Extract here" -> extractZip(item)
                    "Compress to .zip" -> compressSingle(item)
                    "Share" -> shareFile(item)
                    "Delete" -> deleteFile(item)
                }
            }.show()
    }

    private fun extractZip(item: FileItem) {
        thread {
            val result = FileUtils.extractZip(File(item.path), currentDir)
            activity?.runOnUiThread {
                Toast.makeText(
                    requireContext(),
                    if (result != null) "Extracted to ${result.name}" else "Extraction failed",
                    Toast.LENGTH_SHORT
                ).show()
                loadCurrentDir()
            }
        }
    }

    private fun compressSingle(item: FileItem) {
        thread {
            val zip = FileUtils.compressToZip(listOf(File(item.path)), currentDir, item.name)
            activity?.runOnUiThread {
                Toast.makeText(
                    requireContext(),
                    if (zip != null) "Created ${zip.name}" else "Compression failed",
                    Toast.LENGTH_SHORT
                ).show()
                loadCurrentDir()
            }
        }
    }

    private fun bulkZip() {
        val selected = adapter.getSelectedItems()
        if (selected.isEmpty()) return
        val input = EditText(requireContext()).apply { setText("archive"); setSelection(text.length) }
        android.app.AlertDialog.Builder(requireContext())
            .setTitle("Zip name")
            .setView(input)
            .setPositiveButton("Create") { _, _ ->
                val name = input.text.toString().ifBlank { "archive" }
                thread {
                    val zip = FileUtils.compressToZip(selected.map { File(it.path) }, currentDir, name)
                    activity?.runOnUiThread {
                        Toast.makeText(
                            requireContext(),
                            if (zip != null) "Created ${zip.name}" else "Compression failed",
                            Toast.LENGTH_SHORT
                        ).show()
                        exitSelectionMode()
                        loadCurrentDir()
                    }
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun bulkDelete() {
        val selected = adapter.getSelectedItems()
        if (selected.isEmpty()) return
        android.app.AlertDialog.Builder(requireContext())
            .setTitle("Delete ${selected.size} item(s)?")
            .setMessage("This will permanently delete the selected files and folders.")
            .setPositiveButton("Delete") { _, _ ->
                thread {
                    var okCount = 0
                    for (item in selected) {
                        if (File(item.path).deleteRecursively()) {
                            okCount++
                            FavoritesManager.remove(requireContext(), item.path)
                        }
                    }
                    activity?.runOnUiThread {
                        Toast.makeText(requireContext(), "Deleted $okCount / ${selected.size}", Toast.LENGTH_SHORT).show()
                        exitSelectionMode()
                        loadCurrentDir()
                    }
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun bulkCopyOrMove(move: Boolean) {
        val selected = adapter.getSelectedItems()
        if (selected.isEmpty()) return
        FolderPickerDialog(requireContext(), currentDir) { destination ->
            thread {
                var okCount = 0
                for (item in selected) {
                    val source = File(item.path)
                    if (destination.absolutePath == source.parentFile?.absolutePath) continue
                    val ok = if (move) FileUtils.moveInto(source, destination) else FileUtils.copyRecursive(source, destination)
                    if (ok) okCount++
                }
                activity?.runOnUiThread {
                    Toast.makeText(
                        requireContext(),
                        "${if (move) "Moved" else "Copied"} $okCount / ${selected.size}",
                        Toast.LENGTH_SHORT
                    ).show()
                    exitSelectionMode()
                    loadCurrentDir()
                }
            }
        }.show()
    }

    private fun showCreateFolderDialog() {
        val input = EditText(requireContext()).apply { hint = "Folder name" }
        android.app.AlertDialog.Builder(requireContext())
            .setTitle("New folder")
            .setView(input)
            .setPositiveButton("Create") { _, _ ->
                val name = input.text.toString()
                val created = FileUtils.createFolder(currentDir, name)
                if (created != null) {
                    Toast.makeText(requireContext(), "Folder created", Toast.LENGTH_SHORT).show()
                    loadCurrentDir()
                } else {
                    Toast.makeText(requireContext(), "Could not create folder (empty name or already exists)", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    /** Public entry point so other screens (e.g. the FAB in MainActivity) can trigger this. */
    fun promptNewFolder() = showCreateFolderDialog()

    private fun showRenameDialog(item: FileItem) {
        val input = EditText(requireContext()).apply { setText(item.name); setSelection(item.name.length) }
        android.app.AlertDialog.Builder(requireContext())
            .setTitle("Rename")
            .setView(input)
            .setPositiveButton("Rename") { _, _ ->
                val newName = input.text.toString()
                val renamed = FileUtils.renameFile(File(item.path), newName)
                if (renamed != null) {
                    Toast.makeText(requireContext(), "Renamed", Toast.LENGTH_SHORT).show()
                    loadCurrentDir()
                } else {
                    Toast.makeText(requireContext(), "Could not rename (empty name or already exists)", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showDestinationPicker(item: FileItem, move: Boolean) {
        FolderPickerDialog(requireContext(), currentDir) { destination ->
            thread {
                val source = File(item.path)
                if (destination.absolutePath == source.parentFile?.absolutePath) {
                    activity?.runOnUiThread {
                        Toast.makeText(requireContext(), "Already in this folder", Toast.LENGTH_SHORT).show()
                    }
                    return@thread
                }
                val ok = if (move) FileUtils.moveInto(source, destination) else FileUtils.copyRecursive(source, destination)
                activity?.runOnUiThread {
                    Toast.makeText(
                        requireContext(),
                        if (ok) (if (move) "Moved" else "Copied") else "Operation failed",
                        Toast.LENGTH_SHORT
                    ).show()
                    loadCurrentDir()
                }
            }
        }.show()
    }

    private fun shareFile(item: FileItem) {
        try {
            val file = File(item.path)
            val uri = FileProvider.getUriForFile(
                requireContext(), "${requireContext().packageName}.fileprovider", file
            )
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "*/*"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(intent, "Share ${item.name}"))
        } catch (e: Exception) {
            Toast.makeText(requireContext(), "Unable to share file", Toast.LENGTH_SHORT).show()
        }
    }

    private fun deleteFile(item: FileItem) {
        android.app.AlertDialog.Builder(requireContext())
            .setTitle("Delete ${item.name}?")
            .setMessage("This will permanently delete the file from your device.")
            .setPositiveButton("Delete") { _, _ ->
                val ok = File(item.path).deleteRecursively()
                if (ok) FavoritesManager.remove(requireContext(), item.path)
                Toast.makeText(
                    requireContext(),
                    if (ok) "Deleted" else "Could not delete file",
                    Toast.LENGTH_SHORT
                ).show()
                loadCurrentDir()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}

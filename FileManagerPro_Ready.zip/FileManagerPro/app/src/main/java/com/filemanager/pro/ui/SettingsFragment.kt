package com.filemanager.pro.ui

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.filemanager.pro.R
import com.filemanager.pro.util.PinManager

class SettingsFragment : Fragment(R.layout.fragment_settings) {

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        view.findViewById<View>(R.id.rowChangePin).setOnClickListener {
            // Real reset: PinManager clears the stored hash, so LoginActivity's
            // "create PIN" flow runs again the next time the app/lock screen opens.
            PinManager.clearPin(requireContext())
            val intent = Intent(requireContext(), LoginActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
        }

        view.findViewById<View>(R.id.rowStoragePerm).setOnClickListener {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                try {
                    val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION)
                    intent.data = Uri.parse("package:${requireContext().packageName}")
                    startActivity(intent)
                } catch (e: Exception) {
                    startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
                }
            } else {
                val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS)
                intent.data = Uri.parse("package:${requireContext().packageName}")
                startActivity(intent)
            }
        }

        view.findViewById<View>(R.id.rowClearCache).setOnClickListener {
            val cleared = requireContext().cacheDir.deleteRecursively()
            Toast.makeText(
                requireContext(),
                if (cleared) "Cache cleared" else "Nothing to clear",
                Toast.LENGTH_SHORT
            ).show()
        }

        view.findViewById<View>(R.id.rowAbout).setOnClickListener {
            val pkgInfo = requireContext().packageManager.getPackageInfo(requireContext().packageName, 0)
            Toast.makeText(
                requireContext(),
                "File Manager Pro v${pkgInfo.versionName}\nBy Eng. Youssef Abdelghafar",
                Toast.LENGTH_LONG
            ).show()
        }
    }
}

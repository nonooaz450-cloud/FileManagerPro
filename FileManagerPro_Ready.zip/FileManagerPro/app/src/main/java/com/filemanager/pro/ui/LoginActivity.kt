package com.filemanager.pro.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.filemanager.pro.R
import com.filemanager.pro.util.PinManager

class LoginActivity : AppCompatActivity() {

    private lateinit var dots: List<android.view.View>
    private lateinit var tvTitle: TextView
    private lateinit var tvError: TextView
    private var entered = StringBuilder()
    private var firstPin: String? = null // used during PIN creation (confirm step)
    private var isCreatingPin = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        tvTitle = findViewById(R.id.tvPinTitle)
        tvError = findViewById(R.id.tvError)
        dots = listOf(
            findViewById(R.id.dot1), findViewById(R.id.dot2),
            findViewById(R.id.dot3), findViewById(R.id.dot4)
        )

        isCreatingPin = !PinManager.hasPin(this)
        tvTitle.text = if (isCreatingPin) getString(R.string.create_pin) else getString(R.string.enter_pin)

        val tvForgot = findViewById<TextView>(R.id.tvForgotPin)
        tvForgot.visibility = if (isCreatingPin) TextView.GONE else TextView.VISIBLE
        tvForgot.setOnClickListener { showForgotPinDialog() }

        val keyIds = intArrayOf(
            R.id.key1, R.id.key2, R.id.key3, R.id.key4, R.id.key5,
            R.id.key6, R.id.key7, R.id.key8, R.id.key9, R.id.key0
        )
        val digits = listOf("1","2","3","4","5","6","7","8","9","0")
        keyIds.forEachIndexed { i, id ->
            findViewById<TextView>(id).setOnClickListener { onDigit(digits[i]) }
        }
        findViewById<TextView>(R.id.keyDel).setOnClickListener { onDelete() }
    }

    private fun showForgotPinDialog() {
        android.app.AlertDialog.Builder(this)
            .setTitle("Forgot your PIN?")
            .setMessage("Resetting will erase your current PIN. You'll create a new one right after, and your files stay untouched — only the lock resets.")
            .setPositiveButton("Reset PIN") { _, _ ->
                PinManager.clearPin(this)
                isCreatingPin = true
                firstPin = null
                entered.clear()
                updateDots()
                tvTitle.text = getString(R.string.create_pin)
                findViewById<TextView>(R.id.tvForgotPin).visibility = TextView.GONE
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun onDigit(d: String) {
        if (entered.length >= 4) return
        entered.append(d)
        updateDots()
        if (entered.length == 4) {
            android.os.Handler(mainLooper).postDelayed({ handleComplete() }, 150)
        }
    }

    private fun onDelete() {
        if (entered.isNotEmpty()) {
            entered.deleteCharAt(entered.length - 1)
            updateDots()
        }
    }

    private fun updateDots() {
        dots.forEachIndexed { i, view ->
            view.setBackgroundResource(
                if (i < entered.length) R.drawable.pin_dot_filled else R.drawable.pin_dot_empty
            )
        }
    }

    private fun handleComplete() {
        val pin = entered.toString()
        if (isCreatingPin) {
            if (firstPin == null) {
                firstPin = pin
                entered.clear(); updateDots()
                tvTitle.text = getString(R.string.confirm_pin)
            } else {
                if (firstPin == pin) {
                    PinManager.setPin(this, pin)
                    proceedToPermissions()
                } else {
                    showError()
                    firstPin = null
                    tvTitle.text = getString(R.string.create_pin)
                }
            }
        } else {
            if (PinManager.verifyPin(this, pin)) {
                proceedToPermissions()
            } else {
                showError()
            }
        }
    }

    private fun showError() {
        tvError.visibility = TextView.VISIBLE
        entered.clear()
        updateDots()
        android.os.Handler(mainLooper).postDelayed({ tvError.visibility = TextView.INVISIBLE }, 1500)
    }

    private fun proceedToPermissions() {
        if (hasAllFilesPermission()) {
            goToMain()
        } else {
            requestAllFilesPermission()
        }
    }

    private fun hasAllFilesPermission(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            android.os.Environment.isExternalStorageManager()
        } else {
            ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) ==
                PackageManager.PERMISSION_GRANTED
        }
    }

    private fun requestAllFilesPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            try {
                val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION)
                intent.data = Uri.parse("package:$packageName")
                startActivityForResult(intent, REQ_ALL_FILES)
            } catch (e: Exception) {
                startActivityForResult(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION), REQ_ALL_FILES)
            }
        } else {
            ActivityCompat.requestPermissions(
                this,
                arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE),
                REQ_LEGACY_STORAGE
            )
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_ALL_FILES) {
            // Whether granted or not, move forward — Home screen will show a
            // "grant access" prompt if still missing, so the user is never stuck.
            goToMain()
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<out String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_LEGACY_STORAGE) goToMain()
    }

    private fun goToMain() {
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }

    companion object {
        private const val REQ_ALL_FILES = 1001
        private const val REQ_LEGACY_STORAGE = 1002
    }
}

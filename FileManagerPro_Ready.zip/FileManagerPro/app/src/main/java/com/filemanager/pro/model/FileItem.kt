package com.filemanager.pro.model

import java.io.File

data class FileItem(
    val name: String,
    val path: String,
    val isDirectory: Boolean,
    val sizeBytes: Long,
    val lastModified: Long,
    val extension: String
) {
    companion object {
        fun fromFile(file: File): FileItem {
            return FileItem(
                name = file.name,
                path = file.absolutePath,
                isDirectory = file.isDirectory,
                sizeBytes = if (file.isDirectory) 0L else file.length(),
                lastModified = file.lastModified(),
                extension = file.extension.lowercase()
            )
        }
    }
}

data class CategoryItem(
    val key: String,
    val label: String,
    var count: Int,
    val colorHex: String,
    val bgHex: String
)

package com.filemanager.pro.ui

import android.content.Intent
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.filemanager.pro.R
import com.filemanager.pro.adapter.CategoryAdapter
import com.filemanager.pro.adapter.FileAdapter
import com.filemanager.pro.model.CategoryItem
import com.filemanager.pro.util.FileUtils
import com.filemanager.pro.util.StorageUtils
import kotlin.concurrent.thread

class HomeFragment : Fragment(R.layout.fragment_home) {

    private var recentAdapter: FileAdapter? = null
    private var searchJob: Thread? = null

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        loadStorage(view)
        loadCategories(view)
        loadRecentFiles(view)

        view.findViewById<View>(R.id.btnAccessStorage).setOnClickListener {
            (activity as? MainActivity)?.switchToFilesTab()
        }
        view.findViewById<View>(R.id.btnAnalyze).setOnClickListener {
            loadCategories(view); loadStorage(view)
        }

        view.findViewById<SwipeRefreshLayout>(R.id.swipeRefresh).setOnRefreshListener {
            loadStorage(view); loadCategories(view); loadRecentFiles(view)
            view.findViewById<SwipeRefreshLayout>(R.id.swipeRefresh).isRefreshing = false
        }

        wireSearch(view)
        wireTools(view)
    }

    private fun wireSearch(view: View) {
        val etSearch = view.findViewById<EditText>(R.id.etSearch)
        etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val query = s?.toString().orEmpty()
                if (query.isEmpty()) {
                    loadRecentFiles(view)
                    return
                }
                // Debounce so we don't run a real filesystem search on every keystroke.
                searchJob?.interrupt()
                searchJob = thread {
                    Thread.sleep(300)
                    val results = FileUtils.searchFiles(query, maxDepth = 6, limit = 30)
                    activity?.runOnUiThread {
                        if (etSearch.text.toString() == query) {
                            recentAdapter?.updateData(results)
                        }
                    }
                }
            }
        })
        etSearch.setOnEditorActionListener { _, _, _ ->
            val query = etSearch.text.toString()
            if (query.isNotBlank()) openResults(SimpleFileListActivity.MODE_SEARCH, query)
            true
        }
    }

    private fun wireTools(view: View) {
        view.findViewById<View>(R.id.toolRecent).setOnClickListener {
            (activity as? MainActivity)?.let {
                it.findViewById<com.google.android.material.bottomnavigation.BottomNavigationView>(R.id.bottomNav)
                    .selectedItemId = R.id.nav_recent
            }
        }
        view.findViewById<View>(R.id.toolLargeFiles).setOnClickListener {
            openResults(SimpleFileListActivity.MODE_LARGE)
        }
        view.findViewById<View>(R.id.toolDuplicates).setOnClickListener {
            openResults(SimpleFileListActivity.MODE_DUPLICATES)
        }
        view.findViewById<View>(R.id.toolFavorites).setOnClickListener {
            openResults(SimpleFileListActivity.MODE_FAVORITES)
        }
    }

    private fun openResults(mode: String, query: String = "") {
        val intent = Intent(requireContext(), SimpleFileListActivity::class.java)
        intent.putExtra(SimpleFileListActivity.EXTRA_MODE, mode)
        if (query.isNotEmpty()) intent.putExtra(SimpleFileListActivity.EXTRA_QUERY, query)
        startActivity(intent)
    }

    private fun loadStorage(view: View) {
        val stats = StorageUtils.getInternalStorageStats()
        view.findViewById<TextView>(R.id.tvPercent).text = "${stats.usedPercent}%"
        view.findViewById<TextView>(R.id.tvUsedGb).text = StorageUtils.formatBytesGb(stats.usedBytes)
        view.findViewById<TextView>(R.id.tvUsedOf).text =
            "USED OF ${StorageUtils.formatBytesGb(stats.totalBytes)}".uppercase()
        view.findViewById<TextView>(R.id.tvFree).text =
            "●  ${StorageUtils.formatBytesGb(stats.freeBytes)} FREE"
        view.findViewById<ProgressBar>(R.id.storageRing).progress = stats.usedPercent

        val fill = view.findViewById<View>(R.id.progressFill)
        fill.post {
            val parentWidth = (fill.parent as View).width
            val lp = fill.layoutParams
            lp.width = (parentWidth * stats.usedPercent / 100f).toInt()
            fill.layoutParams = lp
        }
    }

    private fun loadCategories(view: View) {
        val rv = view.findViewById<RecyclerView>(R.id.rvCategories)
        rv.layoutManager = GridLayoutManager(requireContext(), 3)

        thread {
            val counts = FileUtils.getCategoryCounts(requireContext())
            val items = listOf(
                CategoryItem("images", "IMAGES", counts["images"] ?: 0, "#C026D3", "#22C026D3"),
                CategoryItem("videos", "VIDEOS", counts["videos"] ?: 0, "#2F8FFF", "#222F8FFF"),
                CategoryItem("audio", "AUDIO", counts["audio"] ?: 0, "#20C96B", "#2220C96B"),
                CategoryItem("documents", "DOCUMENTS", counts["documents"] ?: 0, "#F5A524", "#22F5A524"),
                CategoryItem("apk", "APK", counts["apk"] ?: 0, "#26D0FF", "#2226D0FF"),
                CategoryItem("archives", "ARCHIVES", counts["archives"] ?: 0, "#8B4DFF", "#228B4DFF")
            )
            activity?.runOnUiThread {
                rv.adapter = CategoryAdapter(items) {
                    (activity as? MainActivity)?.switchToFilesTab()
                }
            }
        }
    }

    private fun loadRecentFiles(view: View) {
        val rv = view.findViewById<RecyclerView>(R.id.rvRecentFiles)
        rv.layoutManager = LinearLayoutManager(requireContext())

        thread {
            val files = FileUtils.getRecentFiles(requireContext(), limit = 6)
            activity?.runOnUiThread {
                if (recentAdapter == null) {
                    recentAdapter = FileAdapter(files, onClick = {}, onMoreClick = {})
                    rv.adapter = recentAdapter
                } else {
                    recentAdapter?.updateData(files)
                }
            }
        }
    }
}


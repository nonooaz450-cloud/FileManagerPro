package com.filemanager.pro.util

import android.content.Context
import android.os.Environment
import android.provider.MediaStore
import com.filemanager.pro.model.FileItem
import java.io.File

/**
 * All data here comes from REAL queries against the device's MediaStore
 * and file system. Nothing is mocked.
 */
object FileUtils {

    private val DOC_EXTENSIONS = setOf("pdf", "doc", "docx", "xls", "xlsx", "ppt", "pptx", "txt", "csv")
    private val ARCHIVE_EXTENSIONS = setOf("zip", "rar", "7z", "tar", "gz")

    fun rootDirectory(): File = Environment.getExternalStorageDirectory()

    /** Lists real files/folders inside a directory, sorted: folders first, then by name. */
    fun listDirectory(dir: File): List<FileItem> {
        val children = dir.listFiles() ?: return emptyList()
        return children
            .filter { !it.isHidden }
            .map { FileItem.fromFile(it) }
            .sortedWith(compareByDescending<FileItem> { it.isDirectory }.thenBy { it.name.lowercase() })
    }

    /** Real counts per category, queried from MediaStore + external storage scan. */
    fun getCategoryCounts(context: Context): Map<String, Int> {
        val counts = mutableMapOf(
            "images" to 0, "videos" to 0, "audio" to 0,
            "documents" to 0, "apk" to 0, "archives" to 0
        )

        counts["images"] = countMediaStoreRows(context, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        counts["videos"] = countMediaStoreRows(context, MediaStore.Video.Media.EXTERNAL_CONTENT_URI)
        counts["audio"] = countMediaStoreRows(context, MediaStore.Audio.Media.EXTERNAL_CONTENT_URI)

        // Documents / APK / Archives aren't first-class MediaStore media types,
        // so we do a real (depth-limited) scan of external storage.
        val scanned = scanExtensionCounts(rootDirectory(), maxDepth = 4)
        counts["documents"] = scanned.first
        counts["apk"] = scanned.second
        counts["archives"] = scanned.third

        return counts
    }

    private fun countMediaStoreRows(context: Context, uri: android.net.Uri): Int {
        return try {
            context.contentResolver.query(uri, arrayOf(MediaStore.MediaColumns._ID), null, null, null)
                ?.use { it.count } ?: 0
        } catch (e: SecurityException) {
            0
        }
    }

    private fun scanExtensionCounts(dir: File, maxDepth: Int, depth: Int = 0): Triple<Int, Int, Int> {
        var docs = 0
        var apk = 0
        var archives = 0
        if (depth > maxDepth) return Triple(0, 0, 0)
        val files = dir.listFiles() ?: return Triple(0, 0, 0)
        for (f in files) {
            if (f.isHidden) continue
            if (f.isDirectory) {
                val sub = scanExtensionCounts(f, maxDepth, depth + 1)
                docs += sub.first; apk += sub.second; archives += sub.third
            } else {
                val ext = f.extension.lowercase()
                when {
                    ext == "apk" -> apk++
                    ext in DOC_EXTENSIONS -> docs++
                    ext in ARCHIVE_EXTENSIONS -> archives++
                }
            }
        }
        return Triple(docs, apk, archives)
    }

    /** Real recently modified files across external storage, newest first. */
    fun getRecentFiles(context: Context, limit: Int = 20): List<FileItem> {
        val results = mutableListOf<FileItem>()
        val projection = arrayOf(
            MediaStore.Files.FileColumns.DATA,
            MediaStore.Files.FileColumns.DATE_MODIFIED,
            MediaStore.Files.FileColumns.SIZE
        )
        val sortOrder = "${MediaStore.Files.FileColumns.DATE_MODIFIED} DESC LIMIT $limit"
        try {
            context.contentResolver.query(
                MediaStore.Files.getContentUri("external"),
                projection, null, null, sortOrder
            )?.use { cursor ->
                val dataCol = cursor.getColumnIndexOrThrow(MediaStore.Files.FileColumns.DATA)
                while (cursor.moveToNext()) {
                    val path = cursor.getString(dataCol) ?: continue
                    val f = File(path)
                    if (f.exists() && f.isFile) results.add(FileItem.fromFile(f))
                }
            }
        } catch (e: Exception) {
            // Fall back silently; results stays as already collected
        }
        return results
    }

    /** Real recursive search by filename across external storage (depth-limited so it stays fast). */
    fun searchFiles(query: String, maxDepth: Int = 8, limit: Int = 200): List<FileItem> {
        val q = query.trim().lowercase()
        if (q.isEmpty()) return emptyList()
        val results = mutableListOf<FileItem>()
        searchRecursive(rootDirectory(), q, maxDepth, 0, results, limit)
        return results.sortedByDescending { it.lastModified }
    }

    private fun searchRecursive(
        dir: File, query: String, maxDepth: Int, depth: Int,
        out: MutableList<FileItem>, limit: Int
    ) {
        if (out.size >= limit || depth > maxDepth) return
        val children = dir.listFiles() ?: return
        for (f in children) {
            if (out.size >= limit) return
            if (f.isHidden) continue
            if (f.name.lowercase().contains(query)) out.add(FileItem.fromFile(f))
            if (f.isDirectory) searchRecursive(f, query, maxDepth, depth + 1, out, limit)
        }
    }

    /** Creates a real new folder inside [parent]. Returns the created File, or null on failure/duplicate. */
    fun createFolder(parent: File, name: String): File? {
        val clean = name.trim()
        if (clean.isEmpty()) return null
        val target = File(parent, clean)
        if (target.exists()) return null
        return if (target.mkdir()) target else null
    }

    /** Renames [file] to [newName] within the same directory. Returns the new File, or null on failure/duplicate. */
    fun renameFile(file: File, newName: String): File? {
        val clean = newName.trim()
        if (clean.isEmpty()) return null
        val target = File(file.parentFile, clean)
        if (target.exists()) return null
        return if (file.renameTo(target)) target else null
    }

    /** Copies a file or a whole directory tree from [source] into [destinationDir]. Returns true on full success. */
    fun copyRecursive(source: File, destinationDir: File): Boolean {
        return try {
            val target = uniqueName(destinationDir, source.name)
            if (source.isDirectory) {
                if (!target.mkdirs()) return false
                source.listFiles()?.forEach { child ->
                    if (!copyInto(child, target)) return false
                }
                true
            } else {
                source.inputStream().use { input ->
                    target.outputStream().use { output -> input.copyTo(output) }
                }
                true
            }
        } catch (e: Exception) {
            false
        }
    }

    private fun copyInto(source: File, destinationDir: File): Boolean {
        return try {
            val target = File(destinationDir, source.name)
            if (source.isDirectory) {
                target.mkdirs()
                source.listFiles()?.forEach { child -> if (!copyInto(child, target)) return false }
            } else {
                source.inputStream().use { input ->
                    target.outputStream().use { output -> input.copyTo(output) }
                }
            }
            true
        } catch (e: Exception) {
            false
        }
    }

    /** Moves (cut/paste) [source] into [destinationDir]. Falls back to copy+delete across volumes. */
    fun moveInto(source: File, destinationDir: File): Boolean {
        val target = uniqueName(destinationDir, source.name)
        if (source.renameTo(target)) return true
        // Cross-volume move: copy then delete original.
        return if (copyRecursive(source, destinationDir)) {
            source.deleteRecursively()
        } else false
    }

    /** Avoids overwriting an existing file/folder with the same name at the destination. */
    private fun uniqueName(destinationDir: File, name: String): File {
        var candidate = File(destinationDir, name)
        if (!candidate.exists()) return candidate
        val dot = name.lastIndexOf('.')
        val base = if (dot > 0) name.substring(0, dot) else name
        val ext = if (dot > 0) name.substring(dot) else ""
        var i = 1
        while (candidate.exists()) {
            candidate = File(destinationDir, "$base ($i)$ext")
            i++
        }
        return candidate
    }

    /** Real scan for the largest files on external storage, biggest first. */
    fun findLargestFiles(limit: Int = 50, maxDepth: Int = 8): List<FileItem> {
        val all = mutableListOf<FileItem>()
        collectFiles(rootDirectory(), maxDepth, 0, all)
        return all.sortedByDescending { it.sizeBytes }.take(limit)
    }

    /** Real duplicate scan: groups files that share the same size and name (a fast, dependable-enough heuristic). */
    fun findDuplicateFiles(maxDepth: Int = 8): List<FileItem> {
        val all = mutableListOf<FileItem>()
        collectFiles(rootDirectory(), maxDepth, 0, all)
        return all
            .groupBy { it.sizeBytes to it.name.lowercase() }
            .values
            .filter { it.size > 1 && it[0].sizeBytes > 0 }
            .flatten()
            .sortedWith(compareBy({ it.name.lowercase() }, { it.path }))
    }

    private fun collectFiles(dir: File, maxDepth: Int, depth: Int, out: MutableList<FileItem>) {
        if (depth > maxDepth) return
        val children = dir.listFiles() ?: return
        for (f in children) {
            if (f.isHidden) continue
            if (f.isDirectory) collectFiles(f, maxDepth, depth + 1, out)
            else out.add(FileItem.fromFile(f))
        }
    }

    /**
     * Real ZIP extraction (built on java.util.zip, no external libraries needed).
     * Extracts [zipFile] into a new folder named after the archive, inside [destinationDir].
     * Guards against path-traversal ("zip slip") entries. Returns the created folder, or null on failure.
     */
    fun extractZip(zipFile: File, destinationDir: File): File? {
        val targetDir = uniqueName(destinationDir, zipFile.nameWithoutExtension)
        return try {
            if (!targetDir.mkdirs()) return null
            java.util.zip.ZipInputStream(zipFile.inputStream()).use { zis ->
                var entry = zis.nextEntry
                while (entry != null) {
                    val outFile = File(targetDir, entry.name)
                    // Zip-slip protection: refuse entries that would land outside targetDir.
                    if (!outFile.canonicalPath.startsWith(targetDir.canonicalPath + File.separator)) {
                        zis.closeEntry(); entry = zis.nextEntry; continue
                    }
                    if (entry.isDirectory) {
                        outFile.mkdirs()
                    } else {
                        outFile.parentFile?.mkdirs()
                        outFile.outputStream().use { output -> zis.copyTo(output) }
                    }
                    zis.closeEntry()
                    entry = zis.nextEntry
                }
            }
            targetDir
        } catch (e: Exception) {
            targetDir.deleteRecursively()
            null
        }
    }

    /** Real ZIP creation from one or more files/folders, written with java.util.zip. */
    fun compressToZip(sources: List<File>, destinationDir: File, zipName: String): File? {
        val name = if (zipName.endsWith(".zip", ignoreCase = true)) zipName else "$zipName.zip"
        val zipFile = uniqueName(destinationDir, name)
        return try {
            java.util.zip.ZipOutputStream(zipFile.outputStream()).use { zos ->
                for (source in sources) addToZip(source, source.name, zos)
            }
            zipFile
        } catch (e: Exception) {
            zipFile.delete()
            null
        }
    }

    private fun addToZip(file: File, entryName: String, zos: java.util.zip.ZipOutputStream) {
        if (file.isDirectory) {
            val children = file.listFiles() ?: return
            if (children.isEmpty()) {
                zos.putNextEntry(java.util.zip.ZipEntry("$entryName/"))
                zos.closeEntry()
            } else {
                for (child in children) addToZip(child, "$entryName/${child.name}", zos)
            }
        } else {
            zos.putNextEntry(java.util.zip.ZipEntry(entryName))
            file.inputStream().use { it.copyTo(zos) }
            zos.closeEntry()
        }
    }

    fun getFileTypeLabel(item: FileItem): String {
        if (item.isDirectory) return "FOLDER"
        return when (item.extension) {
            "apk" -> "APK"
            "pdf" -> "PDF"
            "mp4", "mkv", "mov", "avi" -> "VIDEO"
            "jpg", "jpeg", "png", "webp", "gif" -> "IMAGE"
            "mp3", "wav", "m4a", "flac" -> "AUDIO"
            "zip", "rar", "7z" -> "ARCHIVE"
            "doc", "docx" -> "DOCUMENT"
            "xls", "xlsx" -> "SPREADSHEET"
            "txt" -> "TEXT"
            else -> item.extension.uppercase().ifEmpty { "FILE" }
        }
    }
}

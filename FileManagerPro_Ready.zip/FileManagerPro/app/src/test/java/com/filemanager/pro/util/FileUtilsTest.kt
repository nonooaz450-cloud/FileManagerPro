package com.filemanager.pro.util

import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import java.io.File

/**
 * Real tests against the actual file system (a temp directory), not mocks —
 * these exercise the exact code paths used by the Files screen.
 */
class FileUtilsTest {

    private lateinit var root: File

    @Before
    fun setUp() {
        root = File.createTempFile("fmp_test_", "").apply {
            delete(); mkdirs()
        }
    }

    @After
    fun tearDown() {
        root.deleteRecursively()
    }

    @Test
    fun createFolder_makesARealDirectory() {
        val created = FileUtils.createFolder(root, "Notes")
        assertNotNull(created)
        assertTrue(created!!.isDirectory)
        assertTrue(File(root, "Notes").exists())
    }

    @Test
    fun createFolder_refusesDuplicateName() {
        FileUtils.createFolder(root, "Notes")
        val second = FileUtils.createFolder(root, "Notes")
        assertNull(second)
    }

    @Test
    fun createFolder_refusesEmptyName() {
        assertNull(FileUtils.createFolder(root, "   "))
    }

    @Test
    fun renameFile_changesTheNameOnDisk() {
        val file = File(root, "a.txt").apply { writeText("hello") }
        val renamed = FileUtils.renameFile(file, "b.txt")
        assertNotNull(renamed)
        assertFalse(file.exists())
        assertTrue(File(root, "b.txt").exists())
        assertEquals("hello", File(root, "b.txt").readText())
    }

    @Test
    fun renameFile_refusesWhenTargetAlreadyExists() {
        File(root, "a.txt").writeText("a")
        val b = File(root, "b.txt").apply { writeText("b") }
        assertNull(FileUtils.renameFile(b, "a.txt"))
    }

    @Test
    fun copyRecursive_copiesAFileWithoutRemovingTheOriginal() {
        val source = File(root, "doc.txt").apply { writeText("content") }
        val destDir = File(root, "dest").apply { mkdirs() }
        val ok = FileUtils.copyRecursive(source, destDir)
        assertTrue(ok)
        assertTrue(source.exists())
        val copied = File(destDir, "doc.txt")
        assertTrue(copied.exists())
        assertEquals("content", copied.readText())
    }

    @Test
    fun copyRecursive_copiesAWholeFolderTree() {
        val source = File(root, "folder").apply { mkdirs() }
        File(source, "inner.txt").writeText("x")
        val destDir = File(root, "dest").apply { mkdirs() }
        assertTrue(FileUtils.copyRecursive(source, destDir))
        assertTrue(File(destDir, "folder/inner.txt").exists())
    }

    @Test
    fun moveInto_relocatesTheOriginalFile() {
        val source = File(root, "move_me.txt").apply { writeText("y") }
        val destDir = File(root, "dest").apply { mkdirs() }
        assertTrue(FileUtils.moveInto(source, destDir))
        assertFalse(source.exists())
        assertTrue(File(destDir, "move_me.txt").exists())
    }

    @Test
    fun compressAndExtractZip_roundTripsFileContent() {
        val source = File(root, "note.txt").apply { writeText("round trip") }
        val zipDir = File(root, "zips").apply { mkdirs() }
        val zip = FileUtils.compressToZip(listOf(source), zipDir, "backup")
        assertNotNull(zip)
        assertTrue(zip!!.exists())

        val extractDir = File(root, "extracted").apply { mkdirs() }
        val out = FileUtils.extractZip(zip, extractDir)
        assertNotNull(out)
        val extractedFile = File(out, "note.txt")
        assertTrue(extractedFile.exists())
        assertEquals("round trip", extractedFile.readText())
    }

    @Test
    fun getFileTypeLabel_recognizesCommonExtensions() {
        val pdf = FileItem("doc.pdf", "/x/doc.pdf", false, 10, 0, "pdf")
        val folder = FileItem("Photos", "/x/Photos", true, 0, 0, "")
        assertEquals("PDF", FileUtils.getFileTypeLabel(pdf))
        assertEquals("FOLDER", FileUtils.getFileTypeLabel(folder))
    }
}
